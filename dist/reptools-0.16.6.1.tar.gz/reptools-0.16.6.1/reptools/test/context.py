#To be used if I switch to cli-launched tests:
#
#see https://docs.python-guide.org/writing/structure/

#To give the individual tests import context, create a tests/context.py file:

#import os
#import sys
#sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

#import reptools

#Then, within the individual test modules, import the module like so:
#from .context import reptools

